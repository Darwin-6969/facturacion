<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class AuthController extends BaseController
{
    public function index()
    {
        // Si ya está autenticado, redirigir al módulo principal
        if (session()->get('isLoggedIn')) {
            return redirect()->to(base_url('facturacion'));
        }
        return view('auth/login');
    }

    public function authenticate()
{
    $correo = $this->request->getPost('correo');
    $password = $this->request->getPost('password');

    $usuarioModel = new \App\Models\UsuarioModel(); // O el modelo que utilices
    $user = $usuarioModel->where('correo', $correo)->first();

    if ($user) {
        if (password_verify($password, $user['clave'])) {
            // Guardar datos en la sesión
            session()->set([
                'id_usuario' => $user['id_usuario'],
                'nombre'     => $user['nombre'],
                'correo'     => $user['correo'],
                'rol'        => $user['rol'],
                'isLoggedIn' => true,
            ]);

            // Redirigir al dashboard existente
            return redirect()->to(base_url('dashboard'));
        }
    }

    return redirect()->back()->with('error', 'Credenciales incorrectas');
}
}