<aside class="app-sidebar shadow" data-bs-theme="dark">

    <!-- Marca / Logo -->
    <div class="sidebar-brand">
        <a href="<?= base_url('dashboard') ?>" class="brand-link d-flex align-items-center">
            <img src="<?= base_url('assets/img/logo.png') ?>" 
                 alt="Logo Facturación" 
                 style="width: 40px; height: 40px; object-fit: contain; margin-right: 10px;">
            <span class="brand-text fw-semibold">Facturación App</span>
        </a>
    </div>

    <!-- Menú Principal -->
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

                <!-- Dashboard (Ruta independiente) -->
                <li class="nav-item">
                    <a href="<?= base_url('dashboard') ?>" class="nav-link <?= url_is('dashboard') || url_is('/') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-grid-1x2-fill"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <!-- Clientes -->
                <li class="nav-item">
                    <a href="<?= base_url('clientes') ?>" class="nav-link <?= url_is('clientes*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-people-fill"></i>
                        <p>Clientes</p>
                    </a>
                </li>

                <!-- Categorías -->
                <li class="nav-item">
                    <a href="<?= base_url('categorias') ?>" class="nav-link <?= url_is('categorias*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-tags-fill"></i>
                        <p>Categorías</p>
                    </a>
                </li>

                <!-- Marcas -->
                <li class="nav-item">
                    <a href="<?= base_url('marcas') ?>" class="nav-link <?= url_is('marcas*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-bookmark-check-fill"></i>
                        <p>Marcas</p>
                    </a>
                </li>

                <!-- Proveedores -->
                <li class="nav-item">
                    <a href="<?= base_url('proveedores') ?>" class="nav-link <?= url_is('proveedores*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-truck"></i>
                        <p>Proveedores</p>
                    </a>
                </li>

                <!-- Productos -->
                <li class="nav-item">
                    <a href="<?= base_url('productos') ?>" class="nav-link <?= url_is('productos*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-boxes"></i>
                        <p>Productos</p>
                    </a>
                </li>

                <!-- Módulo Facturación (Desplegable) -->
                <li class="nav-item <?= url_is('facturas*') ? 'menu-open' : '' ?>">
                    <a href="#" class="nav-link <?= url_is('facturas*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-receipt-cutoff"></i>
                        <p>
                            Facturación
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <!-- Registrar Nueva Venta -->
                        <li class="nav-item">
                            <a href="<?= base_url('facturas/nueva') ?>" class="nav-link <?= url_is('facturas/nueva') ? 'active' : '' ?>">
                                <i class="nav-icon bi bi-plus-circle"></i>
                                <p>Nueva Factura</p>
                            </a>
                        </li>
                        <!-- Historial de Facturas -->
                        <li class="nav-item">
                            <a href="<?= base_url('facturas') ?>" class="nav-link <?= (url_is('facturas') && !url_is('facturas/nueva')) ? 'active' : '' ?>">
                                <i class="nav-icon bi bi-clock-history"></i>
                                <p>Historial</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Usuarios -->
                <li class="nav-item">
                    <a href="<?= base_url('usuarios') ?>" class="nav-link <?= url_is('usuarios*') ? 'active' : '' ?>">
                        <i class="nav-icon bi bi-person-gear"></i>
                        <p>Usuarios</p>
                    </a>
                </li>

            </ul>
        </nav>
    </div>

</aside>